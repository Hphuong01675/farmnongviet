package com.farmnongviet.exception;

public class GlobalExceptionHandler {

}
