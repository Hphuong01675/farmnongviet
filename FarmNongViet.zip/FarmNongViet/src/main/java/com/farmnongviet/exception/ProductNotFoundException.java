package com.farmnongviet.exception;

public class ProductNotFoundException {

}
