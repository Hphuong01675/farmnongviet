package com.farmnongviet.model;

public class GalleryImage {

}
