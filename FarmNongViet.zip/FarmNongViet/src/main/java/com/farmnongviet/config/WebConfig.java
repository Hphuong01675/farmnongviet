package com.farmnongviet.config;

public class WebConfig {

}
