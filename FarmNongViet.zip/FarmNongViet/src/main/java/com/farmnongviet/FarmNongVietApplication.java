package com.farmnongviet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmNongVietApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmNongVietApplication.class, args);
	}

}
