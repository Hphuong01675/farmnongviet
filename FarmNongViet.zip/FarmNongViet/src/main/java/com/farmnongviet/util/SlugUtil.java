package com.farmnongviet.util;

public class SlugUtil {

}
